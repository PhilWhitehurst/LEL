<?php

/**
* Load child theme sytlesheet
* 
* Set the $deps to 'nudie' to load after the main stylesheet
*/
function child_theme_styles() {

	wp_enqueue_style( 'child-theme-style', get_stylesheet_uri(), array('nudie'), '1.0' );

}

add_action( 'wp_enqueue_scripts', 'child_theme_styles');
